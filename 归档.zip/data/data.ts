import post from './post.json';

import todo from './todo.json'

export class DataStore{
    static post = post;
    static todo = todo;
}
