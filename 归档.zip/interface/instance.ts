export interface NewPost {
    id: string,
    userId: number,
    title: string,
    body: string,
    price: number,
    current: string,
    img:string[]
}